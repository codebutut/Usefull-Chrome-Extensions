const s = document.createElement('script');
s.src = chrome.runtime.getURL('deepl.js');
document.documentElement.prepend(s);
s.onload = function () {
  s.parentNode.removeChild(s);
};
